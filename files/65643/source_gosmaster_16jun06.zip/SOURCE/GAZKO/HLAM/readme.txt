TRichEdit98 is native Delphi 3.0 component which
implements extended rich edit control. TDBRichEdit98
is data-aware verson of TRichEdit98.

The package contains files:

RichEdit2.pas - source code for TRichEdit98 and TDBRichEdit98.
RichEdit2.dcu - compiled unit.
RichEdit2.dcr - resource file.
RTFEditor.pas - source code for property editor.
RTFEditor.dfm - form resource file.
RTFEditor.dcu - compiled unit.
RichOle.pas   - OLE routines for RichEdit (by Greg Chapman <glc@well.com>).
RichOle.pas   - compiled unit.
Langs.pas     - unit which contains some useful declarations and functions.
Langs.dcu     - compiled unit.
WStrList.pas  - source code for TWideStrings object.
WStrList.dcu  - compiled unit.
Help.txt      - flat manual.
Readme.txt    - this file.

To install components in Delphi 3 add file RichEdit2.pas to
any package you want and compile it.
Find TRichEdit98 in Win32 page of components palette.
Find TDBRichEdit98 in Data Controls page of components palette.
For demo see package of TSpellChecker component.

The software is absolutely freeware. To work properly it
requires file RICHED20.DLL in System directory (the file
is part of MS Office 97).

Author will be grateful for any notes and proposals. 


Alexander Obukhov
Minsk, Belarus
E-mail alex@niiomr.belpak.minsk.by