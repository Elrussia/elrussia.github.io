Delphi VCL Extensions (RX) Library 2.32
=======================================

The Set of Native Delphi Components for Borland Delphi
versions 1, 2 & 3 and Borland C++ Builder.
100% Source Code.

Last revision date Jul, 30, 1997.

TABLE OF CONTENTS
-----------------
Overview
Latest Changes
History
Installation
Demonstration Programs
Source Files
Copyright Notes

Overview
--------

    Delphi VCL Extensions (RX) Library contains a large number of components,
objects and routines for Borland Delphi with full source code. This library
is compatible with all Delphi versions (16 & 32 bit), also ready for upcoming
Delphi 3.0, and ready for using with Borland C++ Builder.
    This collection includes over 50 native Delphi components.
    RX Library is a FREEWARE product. Feel free to distribute library
as long as all files are unmodified and kept together.
    The authors disclaim all warranties as to this software, whether express
or implied, including without limitation any implied warranties of
merchantability or fitness for a particular purpose. Use under your own
responsability, but commentaries (even critiques) in English (or in Russian)
are welcome.

  1. Components:
   - TRxDBLookupCombo provides an incremental search through lookup list
by directly typing into the combo control while the lookup list is displayed,
LookupSource can refer to TTable, TQuery, TRxQuery or TQBEQuery. It even
incrementally searches on the query results and much more...
   - TRxDBLookupList is the same as TrxDBLookupCombo (in functionality).
   - TRxDBComboBox is a TDBComboBox descendant allowing to have different
values displayed from that stored in database without using a lookup table.
Allows you to display understandable text versions of stored codes in your
table.
   - TRxDBGrid provides you with the ability to change the background color
and font displayed within individual cells and entire rows and columns;
save and restore columns order and display width in ini-files and system
registry; display icons for BLOB, memo, OLE and picture fields; select
multiple records; convert columns headings to buttons.
   - TDBStatusLabel displays the DataSet state (for all datasets) or current
record number (for DBase or Paradox tables).
   - TDateEdit and TDBDateEdit (data-aware version) allows direct typing and
has a button to bring up calendar in popup window (combo-box alike) or in
a dialog.
   - TQBEQuery enables Delphi applications to use Paradox-style
Query-by-example (QBE) statements to query tables, and perform insert and
update queries.
   - TRxQuery is a TQuery descendant. It supports macros in the SQL text,
which are similar to Params. Macros allow to change query text easily
and handy.
   - TSQLScript allows multiple SQL statements in one query.
   - TRxDBFilter encapsulates BDE ability to filter records locally.
The component provides event on filtering and/or conditions in StringList
property.
   - TDBProgress dispays BDE operations progress for IDAPI drivers
that support callback-functions.
   - TDBIndexCombo is a visual interface component that provides your end-
users with an easy means of changing the current display order of data being
retrived from an indexed table. When the user selects the TDBIndexCombo
component, it's drop-down selection list is populated with the DisplayNames of
all indexes available for the table it's assigned to.
   - TBDEItems, TDatabaseItems, TTableItems are lists populated by the
corresponding BDE information (database list, table list, field list etc).
   - TDBSecurity provides most common dialogs for database applications: Login
Dialog and Change Password Dialog.
   - TRxDBRichEdit - permits the user to display and enter Rich Text Format
(RTF) data in a memo or BLOB field.
   - TAnimatedImage - animation "bitmap by bitmap". Design-time editor allows
you to load Windows animation cursors (ani-files) to this component.
   - TClipboardViewer is a visual control that displays the contents of
Clipboard using different formats.
   - TCurrencyEdit - moneys and numbers input.
   - TPicClip represents a bitmap as the logical array of bitmaps
and supports access by index.
   - TFormPlacement allows to save and restore form size, position and window
state in/from ini-file or Registry.
   - TFormStorage allows you to read and write virtually any component
published property to an INI file or the system Registry with virtually no
code. Works with 3rd party and your own custom controls as well. Don't be
stuck with dozens of INI-Aware components, use TFormStorage and let it
manage all that for you.
   - TPageManager is useful when creating multipage dialogs such as "Experts"
(or "Wizards").
   - TColorComboBox is a combo box to pick up color.
   - TFontComboBox is a combo box to pick up font name.
   - TRxLabel is a customizable shadowed label.
   - TTextListBox is TListBox successor with automatic horizontal scrollbar
if necessary.
   - TRxSplitter separates two controls to allow to change their sizes
in run-time. Never again create a splitter by hand using panel components. Add
splitter support to any application by using the RxSplitter component.
   - TRxSlider and TRxSwitch are slider and switch controls respectively
with the ability to change their looks. TRxSlider provides more features than
the Win32 common control, such as custom thumbs.
   - TRxSpinEdit and TRxSpinButton are spin controls variants.
   - TSpeedBar with horizontal or vertical orientation that can be placed
at the top, bottom, left, right of the form. Customizable in designer
and in run-time using drag&drop operation, similar to Delphi speedbar. Allow
you use flat and transparent buttons such as standard-style buttons. Button's
transparent ability lets graphics show through from under the speedbar.
   - TComboEdit, TFilenameEdit, TDirectoryEdit are the edit boxes with buttons.
User can type data into an edit box or can bring up dialog or popup window by
clicking a button.
   - TMemoryTable implements BDE in-memory table as a data set component
(with Delete operation).
   - TRxCheckListBox is a list box with built-in check boxes.
   - TRxSpeedButton provides you more features than the standard TSpeedButton
component, such as Transparent, Flat and GrayedInactive properties and
Drop-Down Menu.
   - The TRxTimerList component provides all the functions of the standard
TTimer component, plus the additional benefit of using only one Windows timer
for up to 32767 timing events. You can customize this component in designer
using easy-to-use component editor.
   - TConverter, TRxClock, TSecretPanel, TRxDice, TRxCalculator, TRxTrayIcon,
TAppEvents, TStrHolder, TMRUManager, TRxWindowHook and much more.

   2. The editors of standard properties with some advanced features.
   - TPicture and TGraphic adds Copy and Paste Buttons, supports Icons
in Clipboard, uses open dialog box with preview.
   - THint enables multi-line hint entry.

   3. Units that provide functions and objects to work with databases, images,
strings, dates, files, INI-files.

   4. RX Library Help-file in Delphi Help style in Russian ;-(
that can be built into the Delphi multihelp system.

   5. A couple of simple demo applications.

Latest Changes
--------------
    - RX.INC corrected to be C++ Builder aware.
    - Major problems when using the visual form inheritance with TSpeedbar,
TPageManager, TTimerList fixed.
    - TrxDBLookupCombo 16-bit disabled state drawing corrected.
    - TRxCheckListBox GPF fixed when using Clear and Delete methods.
    - Memory leak bug fixed for picture preview dialog.
    - TFormPlacement MinMaxInfo wrong field assignment bug fixed.
    - TFormPlacement GPF fixed when used in MDI-Child forms.
    - Minor problems with TTimerList fixed.
    - Minor Delay function correction.
    - TRxDBGrid minor bug fixed.
    - Minor problems with animated cursors loading fixed.
    - TRxDBLookupList DblClick handling fixed.
    - TRxDBFilter GPF fixed when DataSource is nil.
    - Other minor improvements.

History
-------
    - RX 2.32 (Jul,30,1997). Bug fixes. Full compatibility
with all Delphi versions (including Delphi 3 Professional and Developer
editions) and Borland C++ Builder 1.0. C++ Builder demo.
    - RX 2.31 (May,08,1997). Delphi 3.0 C/S release (build 5.53)
compatibility. Bug fixes.
    - RX 2.30 (Apr,22,1997). New components: TMRUList, TRxTimerList,
TRxWindowHook. Delphi 3 (confidential beta pre-release, build 3.0.4.78)
compatibility. Bug fixes.
    - RX 2.01 (Feb,12,1997), 2.02 (Mar,10,1997). Bug fixes. New component
TRxDBRichEdit. Version 2.02 became available for download on Internet.
    - RX 2.00 (Nov,24,1996). New components: TMemoryTable, TRxCheckListBox,
TRxDBComboBox, TStrHolder, TAppEvents. Bug fixes.
    - RX 1.32 (Nov,11,1996). Delphi 2.0 compatible version. New components:
TSQLScript, TPageManager, TRxTrayIcon.
    - RX 1.03 (Jan,14,1996). Compiled DCU-files removed from installation
package. New components: TFormStorage, TDBSecurity, TRxQuery, TSpeedbar,
TRxSpinButton, TRxSpinEdit, TRxCalculator.
    - RX 1.02 (Dec,27,1995). Private version.
    - RX 1.01 (Dec,04,1995). Bug fixes, new component TRxDBFilter.
    - RX 1.00 (Nov 1995). Initial release for Delphi 1.0 available in
russian Fido.
    - ExtVCL component collections from Apr,25,1995 and Jul,20,1995.

Installation
------------

    Run RXINST.EXE.
    In Delphi 1.0 and 2.0 after installing use the "Install Components..."
item on Delphi's Options menu (or "Component\Install..." in Delphi 2.0)
to add the RxCtlReg.PAS, RxDBReg.PAS and RxTooReg.PAS units to the component
library. This units registers all RX Library components on the "RX Controls",
"RX DBAware" and "RX Tools" pages accordingly.
    In Delphi 3.0 use "File\Open..." menu item to open consistently packages
DCLRXCTL.DPK, DCLRXDB.DPK and DCLRXTLS.DPK. In "Package.." window click
"Install" button to register RX Library components on the "RX Controls",
"RX DBAware" and "RX Tools" pages accordingly.
    WARNING! This version of RX Library was tested only with Delphi 3.0 
build 5.53 (Mar, 20, 1997).

    The help files (in Russian only) are distributing in separate
installation packages for each version of Delphi and C++Builder.

    To install the help and keyword file into Delphi 1.0 and 2.0, follow
these steps:
  - Click on the HelpInst icon in the Delphi group in the Program Manager.
  - Select File|Open from the menu. Change directories so you are in
    the \Delphi\Bin directory, and select the Delphi.hdx file. Click
    the OK button.
  - Select Keywords|Add Keyword File from the menu. Change directories
    so you are in the directory where you stored the help files of the RX.
    Select the RX.KWF (in Delphi 1.0) or RX32.KWF (in Delphi 2.0) file, and
    click the OK button.
  - Select File|Save from the menu. This will recompile the Delphi.hdx
    file. You can then close the Helpinst program. You will now be
    able to jump to the help file for the RX Library by selecting the
    appropriate property and hitting 'F1.'

    Unfortunately, Help file now available is only in Russian. This help
requires Arial Cyr and Courier New Cyr fonts (Windows code page 1251).

C++ Builder Compatibility
-------------------------

    This version of RX Library is compatible with Borland C++ Builder 1.0,
and tested in the Professional edition only.
    RX Library is not tested properly with Borland C++ Builder.
Use under your own responsability.

Demonstration Programs
----------------------
    Demostrations programs included in RX Library use tables from
DELPHI\DEMOS\DATA directory and BDE alias "DBDEMOS".

Source Files
------------

    All sources (100%) of RX Library are available in RX\UNITS directory.
All language specific string constants used in RX Library are collected
in resource files. There are sources for string resource files in English
and Russian. The rest resource files containing bitmap images and icons
for component palette are also included as compiled resorces (*.R16, *.R32)
and as *.RC-files. Resource files sources are available in RX\RESOURCE
directory. So, you can use any resource compiler (i.e. BRC.EXE or BRC32.EXE)
to create *.RES (*.R16 & *.R32) and *.DCR (*.D16 & *.D32) files.

Copyright Notes
---------------
    Most of the modules in library written by us. We have to
make a note of units based on sources of other authors.
    Unit RXLOOKUP is based on original Delphi VCL units DBLOOKUP, DBCTRLS.
    Unit STRUTILS is based on unit of string-handling routines AGSLIB by Alexey 
Lukin, for whom we appreciated during 4 years experience.
    Unit DBEXCPT is modified unit DBEXCEPT.PAS from Borland Delphi 1.0 C/S Demos
DELPHI\DEMOS\DB\TOOLS.
    Some components in unit DBLISTS are based on DELPHI\DEMOS\DB\TOOLS\BDETABLE
unit of Delphi 1.0 Demos.
    Unit PICTEDIT contains advanced property editor based on unit
PICEDIT.PAS from VCL, unit IMAGPRVW.PAS is modified unit IMAGEWIN.PAS from
Borland Delphi 1.0 C/S Demos DELPHI\DEMOS\IMAGVIEW.

    Authors:
        Fedor Koshevnikov  (kosh@masterbank.ru)
        Igor Pavluk        (pavluk@masterbank.ru)
        Serge Korolev      (korolev@masterbank.ru) 
        
        FidoNet: 2:5020/104

        Software development department.
        Master-Bank.
        Moscow, Russia.
